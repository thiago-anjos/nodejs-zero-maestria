const path = require("path");
const basePath = path.join(__dirname, "../template");

module.exports = basePath;
